
Flask-JWT
=========

Flask-JWT is a Flask extension that adds basic Json Web Token features to any application.

Resources
---------

* `Documentation <http://packages.python.org/Flask-JWT/>`_
* `Issue Tracker <https://github.com/mattupstate/flask-jwt/issues>`_
* `Source <https://github.com/mattupstate/flask-jwt>`_
* `Development Version
  <https://github.com/mattupstate/flask-jwt/raw/develop#egg=Flask-JWT-dev>`_



