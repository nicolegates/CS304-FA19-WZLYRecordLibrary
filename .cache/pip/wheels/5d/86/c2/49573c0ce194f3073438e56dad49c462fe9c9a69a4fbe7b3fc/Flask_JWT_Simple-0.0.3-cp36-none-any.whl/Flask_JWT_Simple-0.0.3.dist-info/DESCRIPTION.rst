Simple JWT integration with Flask


